jQuery(document).ready(function () {
     jQuery('#individualtrack').DataTable();
    jQuery('.clear_count').on('click', function (event) {
        var fileid = this.id;
        debugger;
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this counts!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
                .then((willDelete) => {
                    if (willDelete) {
                        var data = 'id=' + fileid + '&action=delete_counts';
                        jQuery.post(audioTracker.ajax_url, data, function (response) {
                            if (response == '0') {
                                swal("Counts are deleted!", {
                                    icon: "success",
                                });
                                window.location.reload();
                            }
                        });
                    } else {
                        swal("Your data is safe!");
                    }
                });
    });
     jQuery(document).on('change','.onoffswitch-checkbox', function (event) {
         debugger;
        if ( jQuery(this).is( ":checked" ) ) {
            var switch_ch="on";
        }
        else{
            var switch_ch="off";
        }
        var data = 'switch=' + switch_ch + '&action=settings_audio';
         jQuery.post(audioTracker.ajax_url, data, function (response) {
        
        });
     });
});