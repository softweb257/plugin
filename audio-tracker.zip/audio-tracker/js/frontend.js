jQuery(document).ready(function() {
        (function ($) {
            var srcs = []; // Array of sources already sent to cut down on posts to server.
            $('audio.wp-audio-shortcode, .wp-audio-playlist audio, .wp-block-audio audio').on('play', function (event) {
                debugger;
                // this.src should be the url (guid) of the audio file
                if (this.src && $.inArray(this.src, srcs) === -1) {
                    srcs.push(this.src);
                    $.post( audioTracker.ajax_url, {
                            action: 'audio_count_tracker',
                            play:1,
                            guid: this.src.replace(/\?.+$/, ''), // Remove any query vars.
                        }, null, 'json'
                    );
                }
            });
            
        })(jQuery);
           jQuery('.download-audio a, .wp-playlist-tracks .wpse-download').on('click', function (event) {
               var srcs = [];
               if (this.href && $.inArray(this.href, srcs) === -1) {
                    srcs.push(this.href);
                    $.post( audioTracker.ajax_url, {
                            action: 'audio_count_tracker',
                            download:1,
                            guid: this.href.replace(/\?.+$/, ''), // Remove any query vars.
                        }, null, 'json'
                    );
                }
             
            });
});