<div class="audio_tracker_main">
    <h1>Audio Tracker</h1>
    <?php
    $args = array
        (
        'post_type' => 'attachment',
        'post_mime_type' => 'audio',
        'numberposts' => -1,
        'orderby' => 'date',
        'order'   => 'ASC',
    );
    $audiofiles = get_posts($args);
    foreach ($audiofiles as $file) {
        $url = wp_get_attachment_url($file->ID);
        $name = $file->post_title;
        $meta = get_post_meta($file->ID, '_wp_attachment_metadata', true);
        $play = ($meta['plays']) ? $meta['plays'] : "0";
        $download = ($meta['downloads']) ? $meta['downloads'] : "0";
        if ($meta['plays'] > 0) {
            $result_play[] = array(
                'count' => $play,
                'name' => $name,
                'url' => $url,
            );
        }
        if ($meta['downloads'] > 0) {
            $result_downlaod[] = array(
                'name' => $name,
                'count' => $download,
                'url' => $url,
            );
        }
    }

    function sort_play($a, $b) {
        return ($a["count"] >= $b["count"]) ? -1 : 1;
    }

    usort($result_play, "sort_play");
    usort($result_downlaod, "sort_play");
    ?>
<div class="panel-stats-section">    
    <div class="panel-stats summary1">
        <h3><span class="icon-topplays"></span>Top Plays</h3>
        <?php if ($result_play) { ?>
        <table class="plain" style="width:50%;">
        <tr>
        <th>Rank</th>
        <th>Title</th>
        <th># Of Plays</th>
        </tr>
            <?php
            
                $i = 1;
                foreach ($result_play as $play) {
                    ?>
                    <tr>
                        <td class="summary-prefix"><?php echo $i; ?></td>
                        <td><span class="summary-title"><?php echo $play['name']; ?></span></td>
                        <td class="summary-number"><span><?php echo $play['count']; ?></span></td>
                    </tr>
                    <?php
                    if ($i == 5)
                        break;
                    $i++;
                }
                ?>
            </table>
        <?php }else { ?>
            <span class="description">No data yet!</span> 
        <?php }
        ?>
    </div>

    <div class="panel-stats summary2">
        <h3><span class="icon-topplays"></span>Top Downloads</h3>
        <?php   if ($result_downlaod) { ?>
        <table class="plain" style="width:50%;">
         <tr>
        <th>Rank</th>
        <th>Title</th>
        <th># Of Downloads</th>
        </tr>
            <?php
          
                $i = 1;
                foreach ($result_downlaod as $play) {
                    ?>
                    <tr>
                        <td class="summary-prefix"><?php echo $i; ?></td>
                        <td><span class="summary-title"><?php echo $play['name']; ?></span></td>
                        <td class="summary-number"><span><?php echo $play['count']; ?></span></td>
                    </tr>
                    <?php
                    if ($i == 5)
                        break;
                    $i++;
                }
                ?>
            </table>
        <?php }else { ?>
            <span class="description">No data yet!</span> 
        <?php }
        ?>
    </div>
</div>
    <div class="file_counts">
    <h3>Individual Track Counts</h3>
        <?php if ($audiofiles) { ?>
            <table id="individualtrack" class="display">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Play</th>
                        <th>Download</th>
                        <th>File URL</th>
                        <th data-orderable="false">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($audiofiles as $file) {
                        $url = wp_get_attachment_url($file->ID);
                        $meta = get_post_meta($file->ID, '_wp_attachment_metadata', true);
                        ?>
                        <tr>
                            <td aria-label="Title"><?php echo $file->post_title; ?></td>
                            <td aria-label="Play"><?php echo ($meta['plays']) ? $meta['plays'] : "0"; ?></td>
                            <td aria-label="Download"><?php echo ($meta['downloads']) ? $meta['downloads'] : "0"; ?></td>
                            <td aria-label="File URL"><?php echo $url; ?></td>
                            <td aria-label="action"><a href="javascript:void(0)" class="clear_count" id="<?php echo $file->ID; ?>">Clear Counts</a></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        <?php } else {
            ?>
            <h4>No Audio files found in media.</h4>
        <?php }
        ?>
    </div>
</div>