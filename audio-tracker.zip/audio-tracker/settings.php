<?php $switch = get_option('on_ip_track'); ?>
<div class="settings_page_main audio_tracker_main">
    <h1>Audio Tracker Settings</h1>
    <h3>You want play & download counts based on IP address?</h3>
    <div class="container">
        <div class="onoffswitch">
            <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox" id="myonoffswitch" <?php echo ($switch == 'on') ? 'checked' : ""; ?>>
            <label class="onoffswitch-label" for="myonoffswitch">
                <div class="onoffswitch-inner"></div>
                <div class="onoffswitch-switch"></div>
            </label>
        </div>
    </div>
</div>