<?php
/*
 * Plugin Name: Audio Tracker
 * Description: This is the custom plugin to track the play and download counts of the audio files.
 * Version: 1.0
 * Author: Chintan
 *
 * WC requires at least: 5.4.4
 * WC tested up to: 4.1
 * 
 */
//ADD MENU LINK AND PAGE FOR AUDIO TRACKER
add_action('admin_menu', 'add_menu_on_dashboard');

function add_menu_on_dashboard() {
    add_menu_page('Audio Tracker', 'Audio Tracker', 'administrator', 'audio-tracker', 'audiotracker_init', 'dashicons-format-audio', '50');
    add_submenu_page('audio-tracker', 'Settings', 'Settings', 'administrator', 'audio-tracker-setting', 'audiotracker_setting');
}

function audiotracker_setting() {
    include("settings.php");
}

function audiotracker_init() {
    include("audio_counts.php");
}
//===================== ENQUEUED CSS AND JS FOR FRONTEND START =======================//
function load_audiotracker_js() {
    wp_enqueue_script('audiotracker_js', plugins_url('/js/frontend.js', __FILE__), array('jquery'));
    $cei = array(
        'RestRoot' => esc_url_raw(rest_url()),
        'plugin_url' => plugins_url('', __FILE__),
        'siteUrl' => site_url(),
        'nonce' => wp_create_nonce('wp_rest'),
        'ajax_url' => admin_url('admin-ajax.php'),
    );
    wp_localize_script('audiotracker_js', 'audioTracker', $cei);
}
add_action('wp_footer', 'load_audiotracker_js');
//===================== ENQUEUED CSS AND JS FOR FRONTEND END =======================//

//====================== ENQUEUED CSS AND JS FOR BACKEND START ====================//
function load_audiotracker_css() { 
    wp_enqueue_style('datatable-css', 'https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css');
    wp_enqueue_style('datatable-cdn-css', 'https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css');
    wp_enqueue_script('datatable_js', 'https://code.jquery.com/jquery-3.5.1.js');
    wp_enqueue_script('datatable_bootstarp_js', 'https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js');
    wp_enqueue_style('audiotracker_css', plugins_url('/css/backend.css', __FILE__));
    wp_enqueue_script('audiotracker_backend_js', plugins_url('/js/backend.js', __FILE__), array('jquery'));
    $cei = array(
        'RestRoot' => esc_url_raw(rest_url()),
        'plugin_url' => plugins_url('', __FILE__),
        'siteUrl' => site_url(),
        'nonce' => wp_create_nonce('wp_rest'),
        'ajax_url' => admin_url('admin-ajax.php'),
    );
    wp_localize_script('audiotracker_backend_js', 'audioTracker', $cei);
    wp_enqueue_script('swal_js', 'https://unpkg.com/sweetalert/dist/sweetalert.min.js');
}
add_action('admin_enqueue_scripts', 'load_audiotracker_css');
//====================== ENQUEUED CSS AND JS FOR BACKEND END ====================//

// =========== ACTION TO ADD PLAY & DOWNLOAD COUNTS START =============================//
add_action('wp_ajax_nopriv_audio_count_tracker', 'audio_count_tracker_callback');
add_action('wp_ajax_audio_count_tracker', 'audio_count_tracker_callback');
function audio_count_tracker_callback() {
    $ret = array('error' => false);
    if (!isset($_REQUEST['guid']) || !( $guid = $_REQUEST['guid'] )) {
        $ret['error'] = __('Params error', 'wpfm');
    } else {
        global $wpdb;
        $sql = $wpdb->prepare('SELECT ID FROM ' . $wpdb->posts . ' WHERE guid = %s LIMIT 1', $guid);
        if ($post_id = $wpdb->get_var($sql)) {
            $ip = bin2hex(inet_pton(preg_replace('/[^0-9a-fA-F:., ]/', '', $_SERVER['REMOTE_ADDR'])));
            $switch = get_option('on_ip_track');
            if ($_REQUEST['play'] == '1') {
                if ($switch == 'on') {
                    if (!( $meta = get_post_meta($post_id, '_wp_attachment_metadata', true) ) || !isset($meta['plays_ips']) || !in_array($ip, $plays_ips = explode(';', $meta['plays_ips']))) {
                        $plays_ips[] = $ip;
                        // If data getting too big, drop off oldest ip (FIFO).
                        if (strlen($meta['play_ips']) > 1000)
                            array_shift($plays_ips);
                        // Save as string to save space.

                        $meta['plays_ips'] = implode(';', $plays_ips);
                        $meta['plays'] = isset($meta['plays']) ? $meta['plays'] + 1 : 1;
                        update_post_meta($post_id, '_wp_attachment_metadata', $meta);
                    }
                }
                else {
                    $meta = get_post_meta($post_id, '_wp_attachment_metadata', true);
                    $meta['plays'] = isset($meta['plays']) ? $meta['plays'] + 1 : 1;
                    update_post_meta($post_id, '_wp_attachment_metadata', $meta);
                }
            }
            if ($_REQUEST['download'] == '1') {
                if ($switch == 'on') {
                    if (!( $meta = get_post_meta($post_id, '_wp_attachment_metadata', true) ) || !isset($meta['download_ips']) || !in_array($ip, $plays_ips = explode(';', $meta['download_ips']))) {
                        $download_ips[] = $ip;
                        // If data getting too big, drop off oldest ip (FIFO).
                        if (strlen($meta['download_ips']) > 1000)
                            array_shift($download_ips);
                        // Save as string to save space.

                        $meta['download_ips'] = implode(';', $download_ips);
                        $meta['downloads'] = isset($meta['downloads']) ? $meta['downloads'] + 1 : 1;
                        update_post_meta($post_id, '_wp_attachment_metadata', $meta);
                    }
                }
                else {
                    $meta = get_post_meta($post_id, '_wp_attachment_metadata', true);
                    $meta['download_ips'] = implode(';', $download_ips);
                    $meta['downloads'] = isset($meta['downloads']) ? $meta['downloads'] + 1 : 1;
                    update_post_meta($post_id, '_wp_attachment_metadata', $meta);
                }
            }
        }
    }
    wp_send_json($ret);
}
// =========== ACTION TO ADD PLAY & DOWNLOAD COUNTS END =============================//

// =================== ACTION TO CLEAR COUNTS START ===============//
add_action('wp_ajax_nopriv_delete_counts', 'clear_countsoffile');
add_action('wp_ajax_delete_counts', 'clear_countsoffile');
function clear_countsoffile() {
    if ($_POST['id']) {
        $post_id = $_POST['id'];
        $meta = get_post_meta($post_id, '_wp_attachment_metadata', true);
        unset($meta['plays']);
        unset($meta['plays_ips']);
        unset($meta['downloads']);
        unset($meta['download_ips']);

        update_post_meta($post_id, '_wp_attachment_metadata', $meta);
        echo '0';
        exit();
    }
}
// =================== ACTION TO CLEAR COUNTS END ===============//

// =================== ACTION FOR SETTINGS START  ===============//
add_action('wp_ajax_settings_audio', 'settings_callback');
add_action('wp_ajax_nopriv_settings_audio', 'settings_callback');
function settings_callback() {
    update_option('on_ip_track', $_POST['switch']);
    echo '0';
    exit();
}
// =================== ACTION FOR SETTINGS END  ===============//